<?php
$dictcode = "mw";
$dictwebversion = "02.004";
?>
